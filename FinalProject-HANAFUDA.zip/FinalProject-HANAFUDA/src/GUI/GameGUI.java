package GUI;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;


public class GameGUI extends JFrame implements ActionListener{

	private JButton[][] jb_area = new JButton[2][4];
	private JButton[][] jb_player1= new JButton[2][4];
	private JButton[][] jb_player2 = new JButton[2][4];
	private JLabel jl_deck;
		
	public GameGUI() {
		// instancier game
		
		// titre & taille
		setTitle("Hanafuda Game");
		setSize(1500,700);
		
		// panel area 
		JPanel panelArea = new JPanel(new GridLayout(2,4,20,20));
		panelArea.setBorder(new EmptyBorder(220, 300, 220, 300));
		// parcourir le tableau pour add chaque butons
		for(int l=0; l<jb_area.length; l++) {
			for(int c=0; c<jb_area[l].length; c++) {
				jb_area[l][c]=new JButton(c+"-"+l);
				panelArea.add(jb_area[l][c]);
			}
		}
		add(panelArea, BorderLayout.CENTER);
		
		JPanel panelPlayer1 = new JPanel(new GridLayout(1,8,20,20));
		panelPlayer1.setBorder(new EmptyBorder(220, 300, 220, 300));
		// parcourir le tableau pour add chaque butons
		for(int l=0; l<jb_player1.length; l++) {
			for(int c=0; c<jb_player1[l].length; c++) {
				jb_player1[l][c]=new JButton(c+"-"+l);
				panelPlayer1.add(jb_area[l][c]);
			}
		}
		add(panelPlayer1, BorderLayout.SOUTH);
		
		JPanel panelPlayer2 = new JPanel(new GridLayout(1,8,20,20));
		panelPlayer2.setBorder(new EmptyBorder(220, 300, 220, 300));
		// parcourir le tableau pour add chaque butons
		for(int l=0; l<jb_player2.length; l++) {
			for(int c=0; c<jb_player2[l].length; c++) {
				jb_player2[l][c]=new JButton(c+"-"+l);
				panelPlayer2.add(jb_player2[l][c]);
			}
		}
		add(panelPlayer2, BorderLayout.NORTH);
	}
	
	/*public static void main(String[] args) {
		GameGUI graphic =new GameGUI();
		graphic.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		graphic.setVisible(true);
	}*/

	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}