package GUI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import card.Area;
import card.Card;
import card.Combos;
import card.Deck;
import card.Player;


public class GameGUI extends JFrame implements ActionListener{

	private JButton[][] jb_area = new JButton[2][8];
	private JButton[] jb_player1Hand= new JButton[8];
	private JButton[] jb_player2Hand = new JButton[8];
	private JLabel[] jl_player1Opponent= new JLabel[8];
	private JLabel[] jl_player2Opponent = new JLabel[8];
	private JLabel[] jl_player1Collection= new JLabel[48];
	private JLabel[] jl_player2Collection = new JLabel[48];
	private JLabel jl_deck;
	
	private Player player1;
	private Player player2;
	private Area area;
	private Deck draw;
	private Combos combos;
	
	private Card selectCard;
	private Card selectAreaCard;
	
	private JFrame player1gui=new JFrame();
	private JFrame player2gui=new JFrame();
	
	
	public void setPlayer(Player one, Player two, Area filed, Deck deck) {
		player1=one;
		player2=two;
		area=filed;
		draw=deck;
	}
		
	public GameGUI(Player one, Player two, Area filed, Deck deck) throws IOException, InterruptedException {
		// instancier game
		setPlayer(one,two,filed, deck);
		setGUI(one, two ,1, "initialize");
		setGUI(two,one ,2, "initialize");
		
		player1gui.setVisible(true);
		player1gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		player2gui.setVisible(true);
		player2gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		boolean run = true;
		int turn = 1 ;
		while (run) {
			
			setGUI(one, two ,1, "Show");
			setGUI(two,one ,2, "Show");
			
			//premiere aprtie du tour
			first((turn==1?player1:player2));
			//deuxieme partie du tour
			second((turn==1?player1:player2));
			combos = new Combos((turn==1?player1.getOwnCard():player2.getOwnCard()));
			
			if(endGame(combos).equalsIgnoreCase("Players don't have card")) {
				//break;
				run=false;
			}else if(endGame(combos).equalsIgnoreCase("Combo")) {
				run=false;
				System.out.println((turn==1?"player 1 ": "player 2 ") + "win with " +combos.getAllCombos());
				setGUI(one, two ,1, "END");
				setGUI(two,one ,2, "END");
				Thread.sleep(10000);
			}
			
			turn=(turn==1?2:1);
		}
		setGUI(one, two ,1, "END");
		setGUI(two,one ,2, "END");
		Thread.sleep(10000);
		player1gui.dispose();
		player2gui.dispose();
		
		
		
	}
	
	public void setGUI(Player player, Player opponent, int playerId, String mode) throws IOException {
		(playerId == 1 ? player1gui : player2gui).getContentPane().removeAll();
		(playerId == 1 ? player1gui : player2gui).getContentPane().repaint();
		JButton[] jb_playerHand;
		JLabel[] jb_playerOpponent;
		if (playerId==1) {
			jb_playerHand = jb_player1Hand;
			jb_playerOpponent = jl_player1Opponent;
		}else {
			jb_playerHand = jb_player2Hand;
			jb_playerOpponent = jl_player2Opponent;
		}
		(playerId == 1 ? player1gui : player2gui).setTitle("Hanafuda Game Player: " + playerId);
		(playerId == 1 ? player1gui : player2gui).setSize(1200,900);
		
		

		JPanel yourCollection = new JPanel(new GridLayout(6,8,10,5));
		yourCollection.setBorder(new EmptyBorder(5, 5, 5, 5));
		System.out.println("J'ai " + player.getOwnCard().size());
		JLabel message= new JLabel("Your Collection");
		yourCollection.add(message);
		for(int l=0; l< player.getOwnCard().size() ; l++) {
			BufferedImage newImage = ImageIO.read(new ByteArrayInputStream(player.getOwnCardByIdx(l).getImage()));
			ImageIcon icon = new ImageIcon(newImage);
			jl_player1Collection[l]=new JLabel(icon);
			yourCollection.add(jl_player1Collection[l]);
		}

		(playerId == 1 ? player1gui : player2gui).add(yourCollection, BorderLayout.EAST);
		(playerId == 1 ? player1gui : player2gui).revalidate();
		
		JPanel opponentCollection = new JPanel(new GridLayout(6,8,5,10));
		opponentCollection.setBorder(new EmptyBorder(5, 5, 5, 5));
		//System.out.println(opponent.getOwnCard().size());

		message= new JLabel("Opponent Collection");
		opponentCollection.add(message);
		for(int l=0; l< opponent.getOwnCard().size() ; l++) {
			BufferedImage newImage = ImageIO.read(new ByteArrayInputStream(opponent.getOwnCardByIdx(l).getImage()));
			ImageIcon icon = new ImageIcon(newImage);
			jl_player2Collection[l]=new JLabel(icon);
			opponentCollection.add(jl_player2Collection[l]);
		}
		
		(playerId == 1 ? player1gui : player2gui).add(opponentCollection, BorderLayout.WEST);
		(playerId == 1 ? player1gui : player2gui).revalidate();
		
		// panel area 
		JPanel panelArea;
		if (mode.equalsIgnoreCase("end")){
			panelArea = new JPanel(new GridLayout(2,4));
			panelArea.setBorder(new EmptyBorder(50, 50, 50, 50));
			message= new JLabel("End of the Game !!! ");
			panelArea.add(message);
			
			message=new JLabel("Player " + (playerId==1?"1":"2") + " Win with this combos:");
			panelArea.add(message);
			
			message=new JLabel(combos.getAllCombos());
			panelArea.add(message);
		}else {
			panelArea = new JPanel(new GridLayout(2,8));
			panelArea.setBorder(new EmptyBorder(2, 2, 2, 2));
			// parcourir le tableau pour add chaque butons
			for(int l=0; l<area.getAreaCardsCount() ; l++) {
				Card areaCard = area.getAreaCard(l);
				BufferedImage Image = ImageIO.read(new ByteArrayInputStream(areaCard.getImage()));
				ImageIcon icon = new ImageIcon(Image);
				JButton btn =new JButton(icon);
				btn.setName(areaCard.getName() + "#A");
				btn.setFocusPainted(false);
				btn.setContentAreaFilled(false);
				btn.setBorder(null);
				btn.addActionListener(this);
	
				if (mode.equalsIgnoreCase("areaSelect")) {
					if (sameMonth(selectCard,areaCard)) {
						btn.setEnabled(true);
					}else {
						btn.setEnabled(false);
						btn.setBackground(Color.gray);
					}
				}else if (mode.equalsIgnoreCase("drawcard")){
					if (l==(area.getAreaCardsCount()-1)){
						btn.setEnabled(false);
					}else if (sameMonth(areaCard, area.getAreaCard(area.getAreaCardsCount()-1))) {
						btn.setEnabled(true);
					}else {
						btn.setEnabled(false);
						btn.setBackground(Color.gray);
					}
				}else if(( mode.equalsIgnoreCase("message") ) || (mode.equalsIgnoreCase("show")) || (mode.equalsIgnoreCase("playerselect") || (mode.equalsIgnoreCase("dropcard")))) {
					btn.setBackground(Color.BLACK);
					btn.setEnabled(false);
					
				} 
				if (l < area.getAreaCardsCount()/2) {
					jb_area[0][l]=btn;
					panelArea.add(jb_area[0][l]);
				}else {
					int newl=l-(area.getAreaCardsCount()/2);
					jb_area[1][newl] = btn;
					panelArea.add(jb_area[1][newl]);					
				}
			}
		}
		//panelArea.setEnabled(false);
		panelArea.setBorder(BorderFactory.createLineBorder(Color.black));
		//panelArea.setBackground(Color.red);
		(playerId == 1 ? player1gui : player2gui).add(panelArea, BorderLayout.CENTER);
		
		
		JPanel yourHand = new JPanel(new GridLayout(2,8,5,5));
		yourHand.setBorder(new EmptyBorder(5, 5, 5, 5));
		// parcourir le tableau pour add chaque butons
		if (mode.equalsIgnoreCase("cantplaydrawcard")) {
			for (int i = 0; i<player.getHandCount()%4; i++) {
				message= new JLabel("");
				yourHand.add(message);
			}
			JTextField mess= new JTextField("Can't play the drawn card");
			yourHand.add(mess);	
			for (int i=0; i< player.getHandCount()%4 ; i++) {
				message= new JLabel("");
				yourHand.add(message);
			}
		}else if (mode.equalsIgnoreCase("PlayerSelect")) {
			for (int i = 0; i<3; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
			message= new JLabel("Choose one of your card");
			yourHand.add(message);			
			for (int i=0; i<4; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
		}else if ((mode.equalsIgnoreCase("AreaSelect")) || (mode.equalsIgnoreCase("DrawCard"))){
			for (int i = 0; i<3; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
			message= new JLabel("Choose an Area Card");
			yourHand.add(message);
			for (int i = 0; i<4; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
		}else{
			for (int i = 0; i<3; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
			message= new JLabel("Wait the opponent please");
			yourHand.add(message);
			for (int i = 0; i<3; i++) {
				message= new JLabel(" ");
				yourHand.add(message);
			}
		}
		for(int l=0; l< jb_playerHand.length ; l++) {
			if (l<player.getHandCount()) {
				Card playerCard = player.getHandCard().get(l);
				BufferedImage newImage = ImageIO.read(new ByteArrayInputStream(playerCard.getImage()));
				ImageIcon icon = new ImageIcon(newImage);
				JButton btn =new JButton(icon);
				btn.setName(playerCard.getName() + "#" + playerId);
				btn.setFocusPainted(false);
				btn.setContentAreaFilled(false);
				btn.setBorder(null);
				btn.addActionListener(this);
				if (mode.equalsIgnoreCase("dropcard")) {
					btn.setEnabled(true);
				}else if(mode.equalsIgnoreCase("AreaSelect")){
					btn.setEnabled(false);
					btn.setBackground(Color.black);	
				}else if (mode.equalsIgnoreCase("drawcard")){
					btn.setEnabled(false);
					btn.setBackground(Color.black);
				}else if (canPlayCard(area.getAreaCards(), playerCard )) {
					btn.setEnabled(true);
				}else if ((!canPlayCard(area.getAreaCards(), playerCard)) || (mode.equalsIgnoreCase("AreaSelect")) ){
					btn.setEnabled(false);
					btn.setBackground(Color.gray);
				}
				
				jb_playerHand[l]=btn;
				yourHand.add(jb_playerHand[l]);	
			}
			
			
		}
		yourHand.setSize(25, 50);
		(playerId == 1 ? player1gui : player2gui).add(yourHand, BorderLayout.SOUTH);
		
		

		BufferedImage back = ImageIO.read(new ByteArrayInputStream(draw.getBackCard().getImage()));
		ImageIcon icon = new ImageIcon(back);
		JPanel opponentHand = new JPanel(new GridLayout(1,8,5,5));
		opponentHand.setBorder(new EmptyBorder(5, 0,5 , 5));
		for(int l=0; l<opponent.getHandCount(); l++) {
			jb_playerOpponent[l]=new JLabel(icon);
			opponentHand.add(jb_playerOpponent[l]);
		}
		opponentHand.setSize(25, 50);
		
		(playerId == 1 ? player1gui : player2gui).add(opponentHand, BorderLayout.NORTH);
		(playerId == 1 ? player1gui : player2gui).revalidate();


	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		boolean check=false;
	    JButton btn = (JButton)e.getSource();
	    System.out.println(btn.getName());
	    
	    if ((!check) && (btn.getName().contains("#1"))) {
	    	for(int card=0; card<jb_player1Hand.length; card++) {
		    	if(btn.getName().equals(jb_player1Hand[card].getName())) {
		    		selectCard=player1.getHandCard().get(card);
		    		check=true;
		    		break;
		    	}
	    	}
	    }else if((!check) && (btn.getName().contains("#2"))) {
	    	for(int card=0; card<jb_player2Hand.length; card++) {
	    		if(btn.getName().equals(jb_player2Hand[card].getName())) {
	    			selectCard=player2.getHandCard().get(card);
	    			check=true;
	    			break;
	    		}
	    	}
	    }else {
		    for(int i=0; i< jb_area.length ; i++) {
			    for(int j=0; j< jb_area[i].length ; j++){
			    	if (jb_area[i][j]!=null) {
			    		if(btn.getName().equals(jb_area[i][j].getName())) {
			    			System.out.println(area.getAreaCardsCount());
				    		selectAreaCard=area.getAreaCard(j+(i==0?0:((area.getAreaCardsCount()))/2));
				    		check=true;
			    			break;
			    		}else {
			    		}
			    	}
			    	
			    }
			    if(check) break;
		    }
		}
	    
	}
	
	
	public void first(Player player) throws IOException, InterruptedException {
	
		setGUI(player, (player==player1)? player2:player1, (player==player1)? 1:2, "PlayerSelect");
		((player==player1)? player1gui:player2gui).setEnabled(true);
		setGUI((player==player1)? player2:player1, player,  (player==player1)? 2:1, "Show");
		((player==player1)? player2gui:player1gui).setEnabled(false);

		boolean canPlay=false;
		for (Card card:player.getHandCard()) {
			if(canPlayCard(area.getAreaCards(), card)) {
				canPlay=true;
			}
		}
		if (canPlay) {			
			selectCard = null;
			//wait value
			while(selectCard==null) {
				Thread.sleep(100);
			}
			System.out.println("->" + selectCard.getName());
		
	
			setGUI(player, (player==player1 ?player2:player1 ), (player==player1 ?1:2 ), "AreaSelect");	
			
			System.out.println("Select Area");
			selectAreaCard = null;
			//wait value
			while(selectAreaCard==null) {
				Thread.sleep(50);
			}
			System.out.println("->" + selectAreaCard.getName());
			
			area.dropCard(selectAreaCard);
			player.playerGive(selectAreaCard);
			player.playerGive(selectCard);
			player.playerDrop(selectCard);
		}else {
			setGUI(player, (player==player1 ?player1:player1 ), (player==player1 ?1:2 ), "DropCard");	
			
			selectCard = null;
			//wait value
			while(selectCard==null) {
				Thread.sleep(100);
			}
			System.out.println("->" + selectCard.getName());
			
			area.fillArea(selectCard);
			player.playerDrop(selectCard);
		}
			
		if(player==player1)player1=player;
		if(player==player2)player2=player;
		
	}
	
	public void second(Player player) throws IOException, InterruptedException {
		setGUI(player1, player2, 1, "Show");
		setGUI(player2, player1, 2, "Show");
		
		draw.DrawCard(area.getAreaCards());
		area.setAreaCardsCount();
		Card drawCard = area.getAreaCard(area.getAreaCardsCount()-1);
		setGUI( player, (player==player1?player2:player1), (player==player1 ? 1:2), "DrawCard");
		Thread.sleep(500);
		Area oldArea = new Area();
		for(int i = 0; i<area.getAreaCardsCount()-1; i++) {
			oldArea.getAreaCards().add(area.getAreaCard(i));
		}
		if (canPlayCard(oldArea.getAreaCards(), drawCard)) {
			selectAreaCard = null;
			//wait value
			while(selectAreaCard==null) {
				Thread.sleep(500);
			}
			
			area.dropCard(selectAreaCard);
			player.playerGive(selectAreaCard);
			player.playerGive(drawCard);
			area.dropCard(drawCard);
		}else {
			setGUI( player, (player==player1?player2:player1), (player==player1 ? 1:2), "CantPlayDrawCard");
			Thread.sleep(5000);
		}
		
		if(player==player1)player1=player;
		if(player==player2)player2=player;
		
	}
	
	public boolean canPlayCard(ArrayList<Card> table, Card card) {
		for (Card targetCard:table) {
			if (sameMonth(targetCard,card)) {
				return true;
			}
		}
		return false;
			
	}
	
	public boolean sameMonth(Card target, Card card) {
		if (target.getMonth().equalsIgnoreCase(card.getMonth()))return true;
		return false;
			
	}
	
	public String endGame(Combos combo) {
		if ((player1.getHandCount()==0) && (player2.getHandCount()==0)) {
			return "Players don't have card";
		}
		if (area.getAreaCardsCount()==0) {
			System.out.println("Area doesn't have card");
			return "Area doesn't have card";
		}
		if(combo.comboCheck.size()>0) {
			return "Combo";
		}
		return "It's not the END";
	}
}


