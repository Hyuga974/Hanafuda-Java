module hanafuda {
	requires java.desktop;
}