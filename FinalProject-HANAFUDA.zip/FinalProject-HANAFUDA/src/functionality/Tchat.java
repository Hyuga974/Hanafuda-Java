package functionality;

import java.util.Random;

public class Tchat {

}
