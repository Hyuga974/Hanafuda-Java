package chat;

import java.util.Random;

public class Tchat {

}
