package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import javax.swing.JFrame;

import card.Game;
import chat.*;
import GUI.GameGUI;
import server.Synchro;

public class ConnectionThread implements Runnable {
	private Server m_dad;
	private Socket m_socket;
	private int id;
	private String name;
	private String state="on";
	private int nb_co= new Server().getNb_co();
	private static Synchro m_game = new Synchro();
	//private CurentGame m_card=new CurentGame();
	
	public Socket getSocket() {
		return m_socket;
	}
	
	public String getName() {
		return name;
	}
		
	public int getMId() {
		return id;
	}
	
	public void setName() {
		name="Player " + id;
	}
	
	public ConnectionThread(Socket socket,Server dad, int nb) {
		m_dad=dad;
		this.m_socket=socket;
		id=nb;
		setName();
	}

	
	
	public void run() {
		try {

			System.out.println("Someone is connect");
			// ouverture du socket ecriture et lecture
				//afficher
			PrintWriter sout = new PrintWriter(m_socket.getOutputStream(), true);
				//r�cup�rer l'input
			BufferedReader sin = new BufferedReader(new InputStreamReader(m_socket.getInputStream()));

			String nameThread=Thread.currentThread().getName();
			sout.println("Hello to you Visitor "+ id);
			sout.println(nameThread);
			
			//boucle infinie server
			while (true) {
								
				if(m_dad.getNb_co()>2) {
					sout.println("Sorry you can't join the server, to much player (max 2)");
					sout.println("Maybe an other time");
					sout.println("See you later !!!!");
					break;
				}
				
				//r�cup�rer l'entr� du client
				String demand=sin.readLine();
					//agir
				if(demand.equalsIgnoreCase("Help")) {
					sout.println("- tchat : Start a discussion with your firend"); 
					sout.println("- Play : Start a game");
					sout.println("- Exit/Quit  : To quit the serv");
					sout.println("- Help : Give you all commands you can use");
				}else if ((demand.equalsIgnoreCase("Exit"))||(demand.equalsIgnoreCase("Quit"))){
					sout.println("See you later !!!!");
					System.out.println("Player " + id + " left the server");
					//m_game.getGUI(id).dispose();
					//m_game.getGUI(id).setTitle("devrait se fermer");
				
					break;
				}else if (demand.equalsIgnoreCase("Tchat")) {
					sout.println("Coming soon");
				}else if (demand.equalsIgnoreCase("Play")) {
					state = "inGame";
					sout.println("The game is in construction");
					System.out.println(m_game.getQueue().size());
					
					if (m_game.getQueue().size()==1) {
						m_game.addQueue(this);	
					}else {
						sout.println("Premier joueur");
						m_game.addQueue(this);
						
					}
					m_game.removeQueue(this);
					sout.println("It was fun no?");
					
				} else if (state!="inGame"){
					sout.println("Unknow command please try Help to know more ;)");
				}
			}
			//fermer le thread
			//m_game.getGUI(id).setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			m_socket.close();
			m_dad.decremente();
			System.out.println("One player left the server");
			
			//suivre le fil actuel
			
			
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}
