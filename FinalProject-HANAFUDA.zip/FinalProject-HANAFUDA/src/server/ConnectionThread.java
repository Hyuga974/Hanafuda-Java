package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ConnectionThread implements Runnable {
	private Server m_dad;
	private Socket m_socket;
	
	public Socket getSocket() {
		return m_socket;
	}
	
	public ConnectionThread(Socket socket,Server dad) {
		m_dad=dad;
		this.m_socket=socket;
	}
	
	

	public void run() {
		try {
			//nomition du thread en cours
			String nameThread=Thread.currentThread().getName();

			System.out.println("Someone is connect");
			// ouverture du socket ecriture et lecture
				//afficher
			PrintWriter sout = new PrintWriter(m_socket.getOutputStream(), true);
				//r�cup�rer l'input
			BufferedReader sin = new BufferedReader(new InputStreamReader(m_socket.getInputStream()));
			
			sout.println("Hello to you Player "+m_dad.getNb_co());
			
			//boucle infinie server
			while (true) {
				if(m_dad.getNb_co()>2) {
					sout.println("Sorry you can't join the server, to much player (max 2)");
					sout.println("Maybe an other time");
					sout.println("See you later !!!!");
					break;
				}
				
				//r�cup�rer l'entr� du client
				String demand=sin.readLine();
					//agir
				if(demand.equalsIgnoreCase("Help")) {
					sout.println("- tchat : Start a discussion with your firend"); 
					sout.println("- Play : Start a game");
					sout.println("- Exit/Quit  : To quit the serv");
					sout.println("- Help : Give you all commands you can use");
				}else if ((demand.equalsIgnoreCase("Exit"))||(demand.equalsIgnoreCase("Quit"))){
					sout.println("See you later !!!!");
					break;
				}else if (demand.equalsIgnoreCase("Tchat")) {
					sout.println("Coming soon");
				}else if (demand.equalsIgnoreCase("Play")) {
					sout.println("The game is in construction");
				} else {
					sout.println("Unknow command please try Help to know more ;)");
				}
			}
			//fermer le thread
			m_socket.close();
			m_dad.decremente();
			System.out.println("One player left the server");
			
			//suivre le fil actuel
			
			
		}catch (Exception e){}
	}
}
