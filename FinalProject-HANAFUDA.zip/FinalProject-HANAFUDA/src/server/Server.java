package server;

import java.net.ServerSocket;
import java.net.Socket;
import server.ConnectionThread;

public class Server {
	private int nb_co=0;
		
	public int getNb_co() {
		return nb_co;
	}
	
	public void increment() {
		nb_co++;
	}
	
	public void decremente() {
		nb_co--;
	}
	
	public Server() {
		try {
			ServerSocket ss = new ServerSocket(9753);
			System.out.println("Waiting connection...");
			while (true) {
				Socket socket= ss.accept();
				increment();
				System.out.println("Player n�" + nb_co + " is coneted"); 
				
                new Thread(new ConnectionThread(socket, this)).start();
			}
		}catch (Exception e){
			System.out.println("We have a problem during the connection:  "+e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		new Server();
	}

}
