package server;

import java.net.ServerSocket;
import java.net.Socket;

import server.ConnectionThread;

public class Server {
	public static ConnectionThread thread1;
	public static ConnectionThread thread2;
	public static ConnectionThread threadTrash;
	private int nb_co=0;

	
	public static ConnectionThread getThread(int id) {
		if (id == 1) {return thread1;}
		if (id == 2) {return thread2;}
		return threadTrash;
	}
	
	public int getNb_co() {
		return nb_co;
	}
	
	public void increment() {
		nb_co++;
	}
	
	public void decremente() {
		nb_co--;
	}
	
	public Server() {
		try {
			ServerSocket ss = new ServerSocket(9753);
			System.out.println("Waiting connection...");
			while (true) { 
				Socket socket= ss.accept();
				increment();
				System.out.println("Player n�" + nb_co + " is coneted"); 
				if (nb_co==1) {
					thread1 = (new ConnectionThread(socket, this, nb_co));
					new Thread(thread1).start();
				}else if (nb_co==2) {
					thread2 = new ConnectionThread(socket, this, nb_co);
					new Thread(thread2).start();
				}else if (nb_co>2) {
					threadTrash = new ConnectionThread(socket, this, nb_co);
					new Thread(threadTrash).start();
				}
			}
		}catch (Exception e){
			System.out.println("We have a problem during the connection:  "+e.getMessage());
		}
	}
	
	public static void main(String[] args) {
		new Server();
	}

}
