package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Socket;


public class Client {

	public Client() {
		//essai
		try {
			//socket <- localhost 1234
			Socket socket = new Socket("localhost" , 9753);
			
			System.out.println("Waiting connection...");
			//mise en place du m�canisme de lecture
			BufferedReader sockin = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			// lire ligne tuyau
			String message = sockin.readLine();
			// l'afficher 
			System.out.println("Server Receipt: " +message);
			//femre le socket
			socket.close();
		}catch(Exception exc) {
			//erreur
		}
			
		
	}
	
	/*public static void main(String[] args) {
		new Client();
	}*/

}
