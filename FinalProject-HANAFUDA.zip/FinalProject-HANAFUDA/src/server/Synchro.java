package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JFrame;

import GUI.GameGUI;
import card.Game;

public class Synchro {
	
	private GameGUI gui1;
	private GameGUI gui2;
	
	public GameGUI getGUI(int id) {
		if(id==1) {return gui1;}
		else {return gui2;}
	}
	
	private int nb_co= new Server().getNb_co();
	public ArrayList<ConnectionThread> allThread=new ArrayList<ConnectionThread>();
	
	public ArrayList<ConnectionThread> Queue=new ArrayList<ConnectionThread>();
	
	public void addQueue(ConnectionThread coT) throws InterruptedException {
		Queue.add(coT);
		if (Queue.size()==2)
			try {
				synchro();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	public void synchro() throws IOException, InterruptedException  {
		ConnectionThread host = Queue.get(0);
		ConnectionThread guest = Queue.get(1);
		allThread.add(host);
		allThread.add(guest);
		
		while (Queue.size()!=2) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		for(ConnectionThread t:allThread) {
			Socket socket = t.getSocket();
			PrintWriter sout = new PrintWriter(socket.getOutputStream(), true);
			if(t.getMId()==1) {sout.println("Your opponent is Visitor" + allThread.get(1).getMId());}
			else{sout.println("Your oppponent is " + allThread.get(0).getName());};
			sout.println(allThread); 
		}
		System.out.println(host.getName());
		System.out.println(allThread.get(0).getName());
		
		if (host.getName()=="Thread-0") {
			play(allThread.get(0),allThread.get(1));
		}else {
			play(allThread.get(1), allThread.get(0));
		}

	}
	
	public void play(ConnectionThread host, ConnectionThread guest) throws IOException, InterruptedException {
		Game myGame = new Game("gui", host, guest);
		
		Socket socket=host.getSocket();
		PrintWriter sout = new PrintWriter(socket.getOutputStream(), true);
		sout.println(myGame.print(host.getMId()));
		/*gui1=new GameGUI(host.getMId(), myGame.player1, myGame.player2, myGame.area);
		gui1.setTitle("Hanafuda Game Host: " + host.getMId());
		gui1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui1.setVisible(true);*/
		socket=guest.getSocket();
		sout = new PrintWriter(socket.getOutputStream(), true);
		sout.println(myGame.print(guest.getMId()));
		/*gui2=new GameGUI(guest.getMId(), myGame.player1, myGame.player2, myGame.area);
		gui2.setTitle("Hanafuda Game guest: " + guest.getMId());
		gui2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui2.setVisible(true);*/
	}
	
}
