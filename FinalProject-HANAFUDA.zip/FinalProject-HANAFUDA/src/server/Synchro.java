package server;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JFrame;

import GUI.GameGUI;
import card.Game;

public class Synchro {
	
	private GameGUI gui1;
	private GameGUI gui2;
	
	public GameGUI getGUI(int id) {
		if(id==1) {return gui1;}
		else {return gui2;}
	}
	
	private int nb_co= new Server().getNb_co();
	public ArrayList<ConnectionThread> allThread=new ArrayList<ConnectionThread>();
	
	public ArrayList<ConnectionThread> Queue=new ArrayList<ConnectionThread>();
	
	public ArrayList<ConnectionThread> getQueue(){
		return Queue;
	}
	
	public void addQueue(ConnectionThread coT) throws InterruptedException {
		Queue.add(coT);
		if (Queue.size()==2) {
			try {
				synchro();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			coT.wait();
		}
	}
	
	public void removeQueue(ConnectionThread coT) throws InterruptedException {
		Queue.remove(coT);
	}
	
	public void synchro() throws IOException, InterruptedException  {
		ConnectionThread host = Queue.get(0);
		ConnectionThread guest = Queue.get(1);
		allThread.add(host);
		allThread.add(guest);
		
		while (Queue.size()!=2) {
			try {
				this.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		for(ConnectionThread t:allThread) {
			Socket socket = t.getSocket();
			PrintWriter sout = new PrintWriter(socket.getOutputStream(), true);
			sout.println("Your opponent is Visitor" + allThread.get((t.getMId()==1?1:0)).getMId());
		}
		
		if (host.getName()=="Thread-0") {
			play(allThread.get(0),allThread.get(1));
		}else {
			play(allThread.get(1), allThread.get(0));
		}
		
		removeQueue(guest);
		removeQueue(host);

	}
	
	public void play(ConnectionThread host, ConnectionThread guest) throws IOException, InterruptedException {
		Game myGame = new Game("gui", host, guest);
		System.out.println("HERE !!!!!!");

	}
	
}
