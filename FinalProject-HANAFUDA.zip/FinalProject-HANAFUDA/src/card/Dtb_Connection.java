package card;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class Dtb_Connection {
	private Connection m_connection;
	
	public Dtb_Connection(String base, String IP, String user, String pass) {
		try {
			// Chargement du driver
			//String driver = "com.mysql.jdbc.Driver";
			//Class.forName( driver );
			// Connexion 
			String url = "jdbc:mysql://"+IP+"/"+base;
			m_connection=DriverManager.getConnection( url, user,pass );
		} catch( Exception ex ) {
			System.err.println(ex.getMessage());
		}
	}
	
	public Dtb_Connection(String base) {
		this(base, "localhost", "root", "");
	}
	
	public ResultSet query(String sql) {
		try {
			Statement instruction = m_connection.createStatement();
			ResultSet resultat = instruction.executeQuery(sql);
			return resultat;
		} catch( Exception ex ) {
			System.err.println(ex.getMessage());
			return null;
		}
	}
	public int update(String sql) {
		try {
			Statement instruction = m_connection.createStatement();
			int resultat = instruction.executeUpdate(sql);
			return resultat;
		} catch( Exception ex ) {
			System.err.println(ex.getMessage());
			return -1;
		}
	}
	
	
	
}
