package card;

import java.util.ArrayList;

public class Player {
    public ArrayList<Card> handCard = new ArrayList<Card>();
    public ArrayList<Card> ownCard = new ArrayList<Card>();
    private int handCount=0;
    private int ownCount;
    private int point;

    
    
    public ArrayList<Card> getHandCard() {
		return handCard;
	}
    
	public ArrayList<Card> getOwnCard() {
		return ownCard;
	}
	
	 public String aff() {
	    	String res="Player Cards: ";
	    	for (Card card:handCard) {
	    		res += " - " + card.getMonth() + "\n" ;
	    	}
	    	return res;
	    }

	public Player(int startPoint) {
        point = startPoint;
    }
    
    public void playerDraw(Card drawCard) {
        handCard.add(drawCard);
    }

    public  Card playerPlayCard(int handCardByIdx) {
         if (handCardByIdx >= handCount) return null;
         else {
              Card playCard = handCard.get(handCardByIdx);
              handCard.remove(handCardByIdx);
              handCount--;
              return  playCard;
         }
    }


    public int getHandCount() {
        return handCount;
    }

    public int getOwnCount() {return ownCount;}

    public Card getHandCardByIdx(int idx) {
        if (idx < handCount) return handCard.get(idx);
        else return null;
    }

    public Card getOwnCardByIdx(int idx) {
        if (idx < ownCount) return ownCard.get(idx);
        else return null;
    } 
    
    public void playerGive(Card giveCard) {
        ownCard.add(giveCard);
        //updateOwnedValue(giveCard);
    }

    public int getPoint() {
        return point;
    }

    /*public void updateOwnedValue(Card newOwnedCard) {
        
        int newPoint = 0;
        combo.checkAllCombo(newOwnedCard.getId());
        newPoint = combo.sumUpPoints();
        if (newPoint > point) {
            point = newPoint;
            meetGameEndRequirements = true;
        }
    }
	public void giveUpEndGame() {
        meetGameEndRequirements = false;
    }

    public boolean isMeetGameEndRequirements() {
        return meetGameEndRequirements;
    }*/
}
