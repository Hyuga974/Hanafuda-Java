package card;

import java.util.ArrayList;

public class Player {
    private ArrayList<Card> handCard = new ArrayList<Card>();
    private ArrayList<Card> ownCard = new ArrayList<Card>();
    private int handCount=handCard.size();
    private int ownCount;
    private int point;

    public void setHandCount() {
    	handCount=handCard.size();
    }

    public int getHandCount() {
    	this.setHandCount();
        return handCount;
    }
    
	private void setOwnCount() {
		ownCount=ownCard.size();
	}

    public int getOwnCount() {return ownCount;}

    public Card getHandCardByIdx(int idx) {
        if (idx < handCount) return handCard.get(idx);
        else return null;
    }

    public Card getOwnCardByIdx(int idx) {
        if (idx < ownCount) return ownCard.get(idx);
        else return null;
    } 
    
    
    public ArrayList<Card> getHandCard() {
    	this.setHandCount();
		return handCard;
	}
    
	public ArrayList<Card> getOwnCard() {
		return ownCard;
	}
	
	 public String aff(ArrayList<Card> List) {
    	String res="";
    	int nb=0;
    	for (Card card:List) {
    		res += nb + "-" + card.getName() + '\n' ;
    		nb ++;
    	}

    	handCount=handCard.size();
    	this.setHandCount();
    	this.setOwnCount();
    	return res;
    }


	public Player(int startPoint) {
        point = startPoint;
    }
    
    public void playerDrop(Card drawCard) {
        handCard.remove(drawCard);
    }

    public  Card playerPlayCard(int handCardByIdx) {

    	handCount=handCard.size();
         if (handCardByIdx >= handCount) return null;
         else {
              Card playCard = handCard.get(handCardByIdx);
              handCard.remove(handCardByIdx);
              handCount--;
              return  playCard;
         }
    }

    public void playerGive(Card giveCard) {
        ownCard.add(giveCard);
        ownCount++;
        //updateOwnedValue(giveCard);
    }

    public int getPoint() {
        return point;
    }

    /*public void updateOwnedValue(Card newOwnedCard) {
        
        int newPoint = 0;
        combo.checkAllCombo(newOwnedCard.getId());
        newPoint = combo.sumUpPoints();
        if (newPoint > point) {
            point = newPoint;
            meetGameEndRequirements = true;
        }
    }
	public void giveUpEndGame() {
        meetGameEndRequirements = false;
    }

    public boolean isMeetGameEndRequirements() {
        return meetGameEndRequirements;
    }*/
}
