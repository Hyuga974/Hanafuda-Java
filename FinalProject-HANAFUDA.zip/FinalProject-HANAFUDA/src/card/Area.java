package card;

import java.util.ArrayList;

public class Area {
    private ArrayList<Card> areaCards = new ArrayList<Card>();
    private int areaCardsNum;
    private int areaCardsMax = 16;
    
    public Area() {
        areaCardsNum = 0;
    }
    

    public int getAreaCardsCount() {
    	this.setAreaCardsCount();
        return areaCardsNum;
    }
    
    public void setAreaCardsCount() {
    	areaCardsNum=areaCards.size();
    }
    
    public ArrayList<Card> getAreaCards() {
		return areaCards;
	}
    
    public Card getAreaCard(int index) {
    	return areaCards.get(index); 
    }
    
    public void dropCard(Card c) {
    	areaCards.remove(c);
    }
    
    
    public String aff() {
    	String res="Area Card: ";
    	for (Card card:areaCards) {
    		res += "-" + card.getName() ;
    		res += "\n";
    	}
    	return res;
    }
    
	public boolean isEmpty() {
        return areaCardsNum == 0;
    }

    public boolean fillArea(Card newCard) {
    	areaCardsNum=areaCards.size();
        if (areaCardsNum == areaCardsMax) {return false;}
        areaCards.add(newCard);
        return true;
    }


}