package card;

import java.util.ArrayList;

public class Area {
    public ArrayList<Card> areaCards = new ArrayList<Card>();
    private int areaCardsNum;
    private int areaCardsMax = 16;
    public Area() {
        areaCardsNum = 0;
    }
    
    public ArrayList<Card> getAreaCards() {
		return areaCards;
	}
    
    public String aff() {
    	String res="Area Card: ";
    	for (Card card:areaCards) {
    		res += " - " + card.getMonth() + "\n" ;
    	}
    	return res;
    }
    
	public boolean isEmpty() {
        return areaCardsNum == 0;
    }

    public void rmCard(int rmCardByIdx) {
        /**
         * remove card from area
         */
        if (rmCardByIdx < areaCardsNum) {
            Card rmCard = areaCards.get(rmCardByIdx);
            areaCards.remove(rmCardByIdx);
            areaCardsNum--;
        }
    }

    public boolean fillArea(Card newCard) {
        /**
         * put card on area, don't do any other work
         */
        if (areaCardsNum == areaCardsMax) return false;
        areaCards.add(newCard);
        return true;
    }

    public int getareaCardsCount() {
        return areaCardsNum;
    }

}