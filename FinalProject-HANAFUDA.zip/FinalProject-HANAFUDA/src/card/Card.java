package card;

public class Card {

    private String name;
    private String month;
    private int id;

    public Card(int id, String name, String month)
    {
    	this.id=id;
        this.name = name;
        this.month = month;
    }
    

	public String getName() {
		return name;
	}


	public String getMonth() {
		return month;
	}


	public int getId() {
		return id;
	}


	//DEBUG
	public void printName() {
		System.out.println(name + "_" + month);
	}
}
