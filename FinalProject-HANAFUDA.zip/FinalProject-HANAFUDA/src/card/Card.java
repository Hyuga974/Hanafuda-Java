package card;

public class Card {

    private int id;
    private String month;
    private String category;
    private String type;
    private byte[] image;

    public Card(int id, String month, String category, String type, byte[] image)
    {
    	this.id=id;
        this.month = month;
        this.category = category;
        this.type = type;
        this.image=image;
    }

    

	public int getId() {
		return id;
	}



	public String getMonth() {
		return month;
	}



	public String getCategory() {
		return category;
	}



	public String getType() {
		return type;
	}



	public byte[] getImage() {
		return image;
	}

	public String getName() {
		return category + "_" + month;
	}

	//DEBUG
	public void printName() {
		System.out.println(category + "_" + month);
	}
}
