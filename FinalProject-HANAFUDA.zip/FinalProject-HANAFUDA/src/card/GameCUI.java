package card;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import server.ConnectionThread;

public class GameCUI {
	private static Area area=new Area();
	private static Deck draw=new Deck();
	private static Player player1Game;
	private static Player player2Game;
	private static ConnectionThread player1;
	private static ConnectionThread player2;
	private static int tour=1;
	
	public  GameCUI(ConnectionThread host, ConnectionThread guest, Player one, Player two, Area filed, Deck deck) throws IOException {
		//initialize socket to print on terminal
		Socket socket1=player1.getSocket();
		PrintWriter sout1 = new PrintWriter(socket1.getOutputStream(), true);
		BufferedReader sin = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
		Socket socket2=player2.getSocket();
		PrintWriter sout2 = new PrintWriter(socket2.getOutputStream(), true);
		BufferedReader sin2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
		
		boolean run=true;
		while (run) {
			System.out.println(tour);
			play(tour);
			if (endGame()=="Players don't have card") {
				sout1.println("It's a draw");
				sout2.println("It's a draw");
				run=false;
				break;
			}
			if (endGame()=="Area doesn't have card") {
				sout1.println("It's a draw");
				sout2.println("It's a draw");
				run=false;
				break;
			}
			//if combo break
			if(tour==1) {tour =2;}
			else {tour=1;}
		}
	}

	public void play(int turn) throws IOException {
		
		//initialize socket to print on terminal
		Player player = player1Game;
		Socket socket1=player1.getSocket();
		PrintWriter sout1 = new PrintWriter(socket1.getOutputStream(), true);
		BufferedReader sin = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
		Socket socket2=player2.getSocket();
		PrintWriter sout2 = new PrintWriter(socket2.getOutputStream(), true);
		BufferedReader sin2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
		if (turn==2) {
			player = player2Game;
			socket1=player2.getSocket();
			sout1 = new PrintWriter(socket1.getOutputStream(), true);
			sin = new BufferedReader(new InputStreamReader(socket1.getInputStream()));
			socket2=player1.getSocket();
			sout2 = new PrintWriter(socket2.getOutputStream(), true);
			sin2 = new BufferedReader(new InputStreamReader(socket2.getInputStream()));
		}

	
		
		sout1.println(area.aff());
		sout2.println(area.aff());
		
			sout1.println(player.aff(player.getHandCard()));
			
			// premier tour du joueur 
			if (canPlay(turn)) {
				sout1.println("\nYou can play some card");
				int index=toInt(sin.readLine());
				while ((index==1000) || (index >= player.getHandCount() )) {
					sout1.println("\nPlease choose a card number (before the \"-\")");
					index=toInt(sin.readLine());
				}
				Card cardPlay=player.playerPlayCard(index);
				sout1.println("\nYou choose : " + cardPlay.getName() + "! Choose an areaCard to take it");
				index=toInt(sin.readLine());
				
				while ( (cardPlay==null) || (index >= area.getAreaCardsCount() ) || (index==1000) || (area.getAreaCard(index).getMonth()!=cardPlay.getMonth()) ) {
					System.out.println("Choose a correct card");
					System.out.println(cardPlay.getName());
					System.out.println(index + " - " + area.getAreaCardsCount());
					System.out.println(area.getAreaCard(index).getName());
					sout1.println("\nPlease choose a correct card");
					index=toInt(sin.readLine());
					if ((index==1000) && (index >= player.getHandCount())) {
						sout1.println("\nPlease choose a card number (before the \"-\")");
						index=toInt(sin.readLine());
						continue;
					}
					
					if (area.getAreaCard(index).getMonth().equalsIgnoreCase(cardPlay.getMonth())) {
						break;
					}
				}

				Card areaPlay=area.getAreaCard(index);
				
				sout1.println("\nYou choose " + areaPlay.getName() + " from the area and " + cardPlay.getName() + " from your hand.");
				area.dropCard(areaPlay);
				player.playerGive(areaPlay);
				player.playerGive(cardPlay);
				sout1.println("\nYou have " + player.getOwnCard());
				
			}else {		
				sout1.println("\nYou can't play! Please choose a card to drop it in the area");
				int index=toInt(sin.readLine());
				while ((index==1000)|| (index >=player.getHandCount() )) {
					sout1.println("\nPlease choose a correct card to drop it in the area");
					sout1.println("\nPlease choose a card number (before the \"-\")");
					index=toInt(sin.readLine());
				}
				Card cardPlay=player.playerPlayCard(index);
				sout1.println("\nYou choose " + cardPlay.getName());
				area.fillArea(cardPlay);

				sout1.println("\n" + area.aff());
			}
			
			//deuci�me tour du joueur 
			draw.DrawCard(player.getHandCard());
			System.out.println(player.aff(player.getHandCard()));
			Card cardPlay=player.getHandCard().get(player.getHandCount()-1);
			player.playerDrop(cardPlay);
			sout1.println("\n You drawed this card: " + cardPlay.getName());
			if (canPlayCardDraw(cardPlay)==0) {
				area.fillArea(cardPlay);
				
			}else if (canPlayCardDraw(cardPlay)==1) {
				sout1.println("\n You can associe this card with one other on the table");
				for(Card areaCard:area.getAreaCards()) {
					if (cardPlay.getMonth()==areaCard.getMonth()) {
						player.playerGive(cardPlay);
						player.playerGive(areaCard);
						area.dropCard(areaCard);
						break;
					}
				}
			}else {
				sout1.println("\nPlease choose an area card to get it in your collection");
				int index=toInt(sin.readLine());
				while((index==1000) || (cardPlay.getMonth()!=area.getAreaCard(index).getMonth()) || (index>=player.getHandCount())) {
					if ((index == 1000) && (index >= player.getHandCount())) {
						sout1.println("\nPlease choose a card number (before the \"-\")");
						index=toInt(sin.readLine());
					}else if (cardPlay.getMonth()!=area.getAreaCard(index).getMonth()) {
						sout1.println("\nSelect the good card please");
					}else {
						sout1.println("\nPlease choose a correct area card to get it in your collection");
					}
				}
				Card areaCard=area.getAreaCard(index);
				player.playerGive(cardPlay);
				player.playerGive(areaCard);
				area.dropCard(areaCard);
				
			}
			sout1.println("\nYou have " + player.aff(player.getOwnCard()));
			sout1.println("\n\n\nEnd of your turn");
			
	}
	
	public String endGame() {
		if ((player1Game.getHandCount()==0) && (player2Game.getHandCount()==0)) {
			return "Players don't have card";
		}
		if (area.getAreaCardsCount()==0) {
			System.out.println("Area doesn't have card");
			return "Area doesn't have card";
		}
		return "It's not the END";
	}
	
	public boolean canPlay(int player) {
		int nbCardPlay=0;
		if (player==1) {
			for (Card playerCard:player1Game.getHandCard()) {
				for (Card areaCard:area.getAreaCards()) {
					if (playerCard.getMonth().equalsIgnoreCase(areaCard.getMonth())) {
						nbCardPlay++;
					}
				}
			}
		}else {
			for (Card playerCard:player2Game.getHandCard()) {
				for (Card areaCard:area.getAreaCards()) {
					if (playerCard.getMonth().equalsIgnoreCase(areaCard.getMonth())){
						nbCardPlay++;
					}
				}
			}
		}
		if(nbCardPlay==0) {return false;}
		else {return true;}
			
	}
	
	public int canPlayCardDraw(Card card) {
		int nbPlay=0;
		for (Card areaCard:area.getAreaCards()) {
			if (areaCard.getMonth()==card.getMonth()) {
				nbPlay+=1;
			}
		}
		
		return nbPlay;
	}
	
	public String print(int player) {
		String res = draw.aff();
		res += area.aff();
		
		if (player==1) {
			res += player1Game.aff(player1Game.getHandCard());
		}else if (player==2){
			res += player2Game.aff(player2Game.getHandCard());
		}else {
			res="ERROR";
		}
		return res;
	}
	
	public int toInt(String str) {
		int index;
		try {
			index = Integer.parseInt(str);
		} catch (NumberFormatException e) {
			return 1000;
		}
		return index;
	}

}
