package card;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> cards= new ArrayList<Card>();
    private static final int nb_cards = 4; 
    private String[] arrayMonth = {"January", "February","March", "April", "May", "June", 
    								"July", "August", "September", "October", "November", "December"};


    public void initDeck() {
        int id = 0;
    	for (String month : arrayMonth){
            	System.out.println(month);
            	Card c = new Card(id,"Ouai", month);
                cards.add(c);
                id++;
        }
        Collections.shuffle(cards);
    }

    public Card DrawCard(ArrayList<Card> target) {
        if (!isEmpty()) {
            Card c= cards.get(0);
            cards.remove(0);
            target.add(c);
        }
        return null;
    }
    

    public String aff() {
    	String res="";
    	for (Card card:cards) {
    		res += " - " + card.getMonth() + "\n" ;
    	}
    	return res;
    }
    public boolean isEmpty() {
        return cards.size() == 0;
    }
    
    public Deck() {
        initDeck();
        System.out.println("Initialized !!");
    }
}