package card;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    private ArrayList<Card> cards= new ArrayList<Card>();
    private Card backCard;
    
    public Card getBackCard() {
    	return backCard;
    }
    
    public void initDeck() {
        
        try {
            Dtb_Connection conn = new Dtb_Connection("hanafuda");
            ResultSet resultat = conn.query("SELECT * FROM card");
            while(resultat.next()){
                cards.add(new Card(resultat.getInt("id"),resultat.getString("month"),resultat.getString("category")
                        ,resultat.getString("type"),resultat.getBytes("image")));
                
            }
            backCard=cards.get(cards.size()-1);
            cards.remove(cards.size()-1);
            System.out.println(cards.size());
        }catch (Exception exc) {
            System.err.println(exc.getMessage());
        }
        
        Collections.shuffle(cards);
    }
        
    public void DrawCard(ArrayList<Card> target) {
        if (!isEmpty()) {
            Card c= cards.get(0) ;
            cards.remove(0);
            target.add(c);
            
            
        }
    }
    

    public String aff() {
    	String res="The draw: \n";
    	for (Card card:cards) {
    		res += "-" + card.getMonth() + " " ;
    	}
    	return res;
    }
    public boolean isEmpty() {
        return cards.size() == 0;
    }
    
    public Deck() {
        initDeck();
        System.out.println("Initialized !!");
    }
}