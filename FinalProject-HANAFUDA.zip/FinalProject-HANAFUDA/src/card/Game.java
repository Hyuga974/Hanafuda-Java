package card;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import GUI.GameGUI;
import server.ConnectionThread;

public class Game{
	private static Area area=new Area();
	private static Deck draw=new Deck();
	private static Player player1Game;
	private static Player player2Game;
	private static ConnectionThread player1;
	private static ConnectionThread player2;

	public Game(String mode, ConnectionThread host, ConnectionThread guest) throws IOException, InterruptedException {		
		area = new Area();
		draw = new Deck();
		
		player1 = host;
		player2 = guest;
		player1Game=new Player(0);
		player2Game=new Player(0);
		
		// Initialize the game
		for (int nb_card=0; nb_card < 8; nb_card++) {
			draw.DrawCard(player1Game.getHandCard());
			draw.DrawCard(area.getAreaCards());
			//System.out.println("FP ->" + draw.getFirstCard().getName());
			draw.DrawCard(player2Game.getHandCard());
		}
		player1Game.setHandCount();
		player2Game.setHandCount();
		area.setAreaCardsCount();
		System.out.println("Game initialized ");
		
		if (mode.equalsIgnoreCase("gui")) {
			Area table = area;
			GameGUI gui = new GameGUI(player1Game, player2Game, table, draw);
			
		}else {
			Area table = area;
			GameCUI game = new GameCUI(host, guest,player1Game, player2Game, table, draw);
		}
	}
}

