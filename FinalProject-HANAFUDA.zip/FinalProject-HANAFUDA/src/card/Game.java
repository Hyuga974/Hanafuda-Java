package card;

public class Game{
	public Area area=new Area();
	public Deck draw=new Deck();
	public Player player1=new Player(0);
	public Player player2=new Player(0);
	
	public void print() {
		System.out.println(draw.aff());
		
		// Initialize the game
		for (int nb_card=0; nb_card <= 2; nb_card++) {
			draw.DrawCard(player1.getHandCard());
			draw.DrawCard(area.getAreaCards());
			draw.DrawCard(player2.getHandCard());
		}
		area.getAreaCards().toString();
		player1.aff();
		player2.aff();
	}

}
