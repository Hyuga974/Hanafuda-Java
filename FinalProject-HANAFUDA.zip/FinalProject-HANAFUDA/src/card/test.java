package card;

public class test implements Runnable {

	public void run() {
		;

	}

}
