package card;

import java.util.ArrayList;

public class Combos {
	public ArrayList<Card> collection=new ArrayList<Card>();
	public ArrayList<String> comboCheck = new ArrayList<String>();
	
	public Combos(ArrayList<Card> Collection) {
		collection=Collection;
		
		if(comboKasu())comboCheck.add("Combo Plain");
		if(comboTan())comboCheck.add("Combo Ribbon");
		if(comboAkatan())comboCheck.add("Combo Red ribbon with poem");
		if(comboAotan())comboCheck.add("Combo Blue Ribbon");
		if(comboInoShikaCho())comboCheck.add("Combo with Boar, deer and butterflies");
		if(comboTane())comboCheck.add("Combo Animals");
		if(comboGoko())comboCheck.add("Combo five Lights");
		if(comboShiko())comboCheck.add("Combo four Lights");
		if(comboSanko())comboCheck.add("Combo three Lights");
		if(comboHanamiDeIppai())comboCheck.add("Combo Flowers's contemplation");
		if(comboTsukiDeIppai())comboCheck.add("Combo Moon's contemplation");
		if(comboAmeShiko())comboCheck.add("Combo four Lights with the Rain");
	}
	
	public String getAllCombos() {
		String res="";
		for (String name:comboCheck) {
			res+=name + " !  ";
		}
		return res;
	}
	public boolean comboKasu() {
		int nbKasu=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("plain")) {
				nbKasu++;
			}
		}
		if(nbKasu>=10)return true;
		return false;
	}
	
	public boolean comboTan() {
		int nbTan=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("ribbon")) {
				nbTan++;
			}
		}
		if(nbTan>=5)return true;
		return false;
	}
	
	public boolean comboAkatan() {
		int nbAkatan=0;
		for (Card card:collection) {
			if (card.getType().equalsIgnoreCase("Red Poem Ribbon")) {
				nbAkatan++;
			}
		}
		if(nbAkatan==3)return true;
		return false;
	}
	
	public boolean comboAotan() {
		int nbAkatan=0;
		for (Card card:collection) {
			if (card.getType().equalsIgnoreCase("Blue Poem Ribbon")) {
				nbAkatan++;
			}
		}
		if(nbAkatan==3)return true;
		return false;
	}
	
	public boolean comboTane() {
		int nbTane=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("animal")) {
				nbTane++;
			}
		}
		if(nbTane>=5)return true;
		return false;
	}
	
	public boolean comboInoShikaCho() {
		int nb=0;
		for (Card card:collection) {
			if ( (card.getType().equalsIgnoreCase("deer")) 
					|| (card.getType().equalsIgnoreCase("butterflies")) 
					|| (card.getType().equalsIgnoreCase("boar")) ){
				nb++;
			}
		}
		if(nb==3)return true;
		return false;
	}
	
	public boolean comboTsukiDeIppai() {
		int nb=0;
		for (Card card:collection) {
			if ( (card.getType().equalsIgnoreCase("sake cup"))
					|| (card.getType().equalsIgnoreCase("moon")) ){
				nb++;
			}
		}
		if(nb==2)return true;
		return false;
		
	}
	
	public boolean comboHanamiDeIppai() {
		int nb=0;
		for (Card card:collection) {
			if ( (card.getType().equalsIgnoreCase("sake cup"))
					|| (card.getType().equalsIgnoreCase("curtain")) ){
				nb++;
			}
		}
		if(nb==2)return true;
		return false;
		
	}
	

	public boolean comboSanko() {
		int nbSanko=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("light")){
				if (card.getType().equalsIgnoreCase("rain")) {
					continue;
				}else {
					nbSanko++;	
				}
			}
		}
		if(nbSanko==3)return true;
		return false;
		
	}
	
	public boolean comboShiko() {
		int nbShiko=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("light")){
				if (card.getType().equalsIgnoreCase("rain")) {
					continue;
				}else {
					nbShiko++;	
				}
			}
		}
		if(nbShiko==4)return true;
		return false;
		
	}
	
	public boolean comboAmeShiko() {
		int nbShiko=0;
		boolean rain=false;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("light")){
				if (card.getType().equalsIgnoreCase("rain")) {
					rain=true;
				}else {
					nbShiko++;	
				}
			}
		}
		if((nbShiko==3) && (rain))return true;
		return false;
		
	}
	
	public boolean comboGoko() {
		int nbGoKo=0;
		for (Card card:collection) {
			if (card.getCategory().equalsIgnoreCase("light")){
				nbGoKo++;
			}
		}
		if(nbGoKo==5)return true;
		return false;
		
	}
	
}
