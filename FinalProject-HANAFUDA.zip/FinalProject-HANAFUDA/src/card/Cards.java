package card;

import java.util.ArrayList;
import java.util.Collections;

public class Cards {

    private ArrayList<Card> cards;
    private static final int nb_cards = 14; 
    private String[] arrayColors = {"TREFLE", "COEUR", "PICQUE", "CARREAU"};
    private ArrayList<Card> Deck;
    
    public ArrayList<Card> getDeck() {
        return Deck;
    }


	public int numCardsLeft() {
		return cards.size();
	}

	public Card drawCard() {
		System.out.println("One more!");
		Card c = cards.get(0);
		cards.remove(0);
		return c;
	}

	//DEBUG
	public void printDeck () {
		for (Card c : cards) {
			c.printName();
		}
	}
	
    public Cards()
    {
        Collections.shuffle(Deck);
        this.Deck = new ArrayList<Card>();
        for (int i = 1; i < nb_cards; i++)
        	
        {
            for (String arrayColor : arrayColors)
            {
                Deck.add(new Card(arrayColor, i));
            }
        }
        
    }

}
